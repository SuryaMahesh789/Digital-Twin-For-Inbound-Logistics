import { Component } from '@angular/core';

@Component({
  selector: 'app-p1-vehicle-stores',
  standalone: true,
  imports: [],
  templateUrl: './p1-vehicle-stores.component.html',
  styleUrl: './p1-vehicle-stores.component.scss'
})
export class P1VehicleStoresComponent {

}
