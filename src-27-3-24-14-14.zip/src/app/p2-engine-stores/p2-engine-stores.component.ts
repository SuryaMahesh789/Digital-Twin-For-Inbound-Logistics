import { Component } from '@angular/core';


@Component({
  selector: 'app-p2-engine-stores',
  standalone: true,
  imports: [],
  templateUrl: './p2-engine-stores.component.html',
  styleUrl: './p2-engine-stores.component.scss'
})


export class P2EngineStoresComponent {

}
