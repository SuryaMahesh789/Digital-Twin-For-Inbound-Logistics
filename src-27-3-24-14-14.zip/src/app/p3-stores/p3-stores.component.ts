import { Component } from '@angular/core';

@Component({
  selector: 'app-p3-stores',
  standalone: true,
  imports: [],
  templateUrl: './p3-stores.component.html',
  styleUrl: './p3-stores.component.css'
})
export class P3StoresComponent {

}
