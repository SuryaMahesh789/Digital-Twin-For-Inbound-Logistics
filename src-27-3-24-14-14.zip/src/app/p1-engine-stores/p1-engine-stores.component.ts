import { Component } from '@angular/core';

@Component({
  selector: 'app-p1-engine-stores',
  standalone: true,
  imports: [],
  templateUrl: './p1-engine-stores.component.html',
  styleUrl: './p1-engine-stores.component.scss'
})
export class P1EngineStoresComponent {

}
