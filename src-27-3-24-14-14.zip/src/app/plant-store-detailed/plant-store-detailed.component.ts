import { Component } from '@angular/core';

@Component({
  selector: 'app-plant-store-detailed',
  standalone: true,
  imports: [],
  templateUrl: './plant-store-detailed.component.html',
  styleUrl: './plant-store-detailed.component.css'
})
export class PlantStoreDetailedComponent {

}
