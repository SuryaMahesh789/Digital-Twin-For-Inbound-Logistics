import { Component } from '@angular/core';

@Component({
  selector: 'app-p2-store-layout',
  standalone: true,
  imports: [],
  templateUrl: './p2-store-layout.component.html',
  styleUrl: './p2-store-layout.component.css'
})
export class P2StoreLayoutComponent {

}
