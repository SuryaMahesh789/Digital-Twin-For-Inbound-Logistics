import { Component } from '@angular/core';

@Component({
  selector: 'app-p2-frame-and-paint-stores',
  standalone: true,
  imports: [],
  templateUrl: './p2-frame-and-paint-stores.component.html',
  styleUrl: './p2-frame-and-paint-stores.component.scss'
})
export class P2FrameAndPaintStoresComponent {

}
