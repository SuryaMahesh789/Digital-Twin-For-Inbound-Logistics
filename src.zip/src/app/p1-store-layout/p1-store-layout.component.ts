import { Component } from '@angular/core';

@Component({
  selector: 'app-p1-store-layout',
  standalone: true,
  imports: [],
  templateUrl: './p1-store-layout.component.html',
  styleUrl: './p1-store-layout.component.css'
})
export class P1StoreLayoutComponent {

}
