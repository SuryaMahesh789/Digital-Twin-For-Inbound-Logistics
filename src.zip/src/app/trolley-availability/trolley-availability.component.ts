import { Component } from '@angular/core';

@Component({
  selector: 'app-trolley-availability',
  standalone: true,
  imports: [],
  templateUrl: './trolley-availability.component.html',
  styleUrl: './trolley-availability.component.scss'
})
export class TrolleyAvailabilityComponent {

}
