import { Component } from '@angular/core';

@Component({
  selector: 'app-p2-vehicle-stores',
  standalone: true,
  imports: [],
  templateUrl: './p2-vehicle-stores.component.html',
  styleUrl: './p2-vehicle-stores.component.scss'
})
export class P2VehicleStoresComponent {

}
