import { Component } from '@angular/core';

@Component({
  selector: 'app-p3-store-layout',
  standalone: true,
  imports: [],
  templateUrl: './p3-store-layout.component.html',
  styleUrl: './p3-store-layout.component.css'
})
export class P3StoreLayoutComponent {

}
