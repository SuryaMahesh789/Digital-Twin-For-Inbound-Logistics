import { Component } from '@angular/core';

@Component({
  selector: 'app-p2-vehicle-stores2',
  standalone: true,
  imports: [],
  templateUrl: './p2-vehicle-stores2.component.html',
  styleUrl: './p2-vehicle-stores2.component.scss'
})


export class P2VehicleStores2Component {

}
