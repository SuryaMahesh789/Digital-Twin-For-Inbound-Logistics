import { Component } from '@angular/core';

@Component({
  selector: 'app-p1-plastic-stores',
  standalone: true,
  imports: [],
  templateUrl: './p1-plastic-stores.component.html',
  styleUrl: './p1-plastic-stores.component.css'
})
export class P1PlasticStoresComponent {

}
